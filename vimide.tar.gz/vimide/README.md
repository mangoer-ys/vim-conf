Init VJ!
